from .hypercrypto import *

__doc__ = hypercrypto.__doc__
if hasattr(hypercrypto, "__all__"):
    __all__ = hypercrypto.__all__